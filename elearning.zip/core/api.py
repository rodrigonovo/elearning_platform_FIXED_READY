
from rest_framework import viewsets, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db.models import Q
from .models import User, Course, Enrollment, Feedback, StatusUpdate
from .serializers import (UserPublicSerializer, CourseSerializer, EnrollmentSerializer, 
                          FeedbackSerializer, StatusUpdateSerializer)

class IsTeacher(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and getattr(request.user, "role", "student") == "teacher")

class UserViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = User.objects.all().order_by("username")
    serializer_class = UserPublicSerializer
    permission_classes = [permissions.IsAuthenticated]
    def get_queryset(self):
        qs = super().get_queryset()
        q = self.request.query_params.get("q")
        if q:
            qs = qs.filter(Q(username__icontains=q) | Q(real_name__icontains=q))
        return qs

class CourseViewSet(viewsets.ModelViewSet):
    queryset = Course.objects.select_related("teacher").all().order_by("-created_at")
    serializer_class = CourseSerializer
    permission_classes = [permissions.IsAuthenticated]
    def perform_create(self, serializer):
        serializer.save(teacher=self.request.user)

class EnrollmentViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Enrollment.objects.select_related("student","course","course__teacher").all().order_by("-enrolled_at")
    serializer_class = EnrollmentSerializer
    permission_classes = [permissions.IsAuthenticated]

class FeedbackViewSet(viewsets.ModelViewSet):
    queryset = Feedback.objects.select_related("student","course").all().order_by("-date")
    serializer_class = FeedbackSerializer
    permission_classes = [permissions.IsAuthenticated]
    def perform_create(self, serializer):
        serializer.save(student=self.request.user)

class StatusUpdateViewSet(viewsets.ModelViewSet):
    queryset = StatusUpdate.objects.select_related("user").all().order_by("-timestamp")
    serializer_class = StatusUpdateSerializer
    permission_classes = [permissions.IsAuthenticated]
    def perform_create(self, serializer):
        serializer.save(user=self.request.user)
