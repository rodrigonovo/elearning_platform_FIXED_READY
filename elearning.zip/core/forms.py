from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, Course, Feedback, StatusUpdate

class CustomUserCreationForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "real_name", "photo", "role", "password1", "password2")

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ["name", "description", "materials"]

class FeedbackForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ["rating", "comment"]

class StatusUpdateForm(forms.ModelForm):
    class Meta:
        model = StatusUpdate
        fields = ["content"]
