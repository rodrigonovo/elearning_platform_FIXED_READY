from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models

USER_ROLES = (
    ('student', 'Student'),
    ('teacher', 'Teacher'),
)

class User(AbstractUser):
    """Custom user extending Django's AbstractUser with a role and profile info."""
    real_name = models.CharField(max_length=100, blank=True)
    photo = models.ImageField(upload_to='user_photos/', blank=True, null=True)
    role = models.CharField(max_length=20, choices=USER_ROLES, default='student')

    def __str__(self):
        return self.username

class Course(models.Model):
    """A course created by a teacher."""
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    teacher = models.ForeignKey('User', on_delete=models.CASCADE, related_name='courses')
    materials = models.FileField(upload_to='course_materials/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Enrollment(models.Model):
    """Enrollment linking a student to a course."""
    student = models.ForeignKey('User', on_delete=models.CASCADE, related_name='enrollments')
    course = models.ForeignKey('Course', on_delete=models.CASCADE, related_name='enrollments')
    enrolled_at = models.DateTimeField(auto_now_add=True)
    is_blocked = models.BooleanField(default=False)

    class Meta:
        unique_together = ('student', 'course')

    def __str__(self):
        return f"{self.student.username} -> {self.course.name}"

class Feedback(models.Model):
    """Feedback left by students for a given course."""
    course = models.ForeignKey('Course', on_delete=models.CASCADE, related_name='feedback')
    student = models.ForeignKey('User', on_delete=models.CASCADE, related_name='feedback')
    rating = models.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    comment = models.TextField(blank=True)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback by {self.student.username} for {self.course.name}"

class StatusUpdate(models.Model):
    """Status updates posted by students, visible on their profile."""
    user = models.ForeignKey('User', on_delete=models.CASCADE, related_name='status_updates')
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Status by {self.user.username} at {self.timestamp:%Y-%m-%d %H:%M}"


class Notification(models.Model):
    user = models.ForeignKey('User', on_delete=models.CASCADE, related_name='notifications')
    message = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    def __str__(self):
        return f"To {self.user.username}: {self.message}"
