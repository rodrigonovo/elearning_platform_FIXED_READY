
from rest_framework import serializers
from .models import User, Course, Enrollment, Feedback, StatusUpdate

class UserPublicSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "username", "real_name", "role"]

class CourseSerializer(serializers.ModelSerializer):
    teacher = UserPublicSerializer(read_only=True)
    class Meta:
        model = Course
        fields = ["id", "name", "description", "teacher", "created_at"]

class EnrollmentSerializer(serializers.ModelSerializer):
    student = UserPublicSerializer(read_only=True)
    course = CourseSerializer(read_only=True)
    class Meta:
        model = Enrollment
        fields = ["id", "student", "course", "enrolled_at", "is_blocked"]

class FeedbackSerializer(serializers.ModelSerializer):
    student = UserPublicSerializer(read_only=True)
    class Meta:
        model = Feedback
        fields = ["id", "course", "student", "rating", "comment", "date"]

class StatusUpdateSerializer(serializers.ModelSerializer):
    user = UserPublicSerializer(read_only=True)
    class Meta:
        model = StatusUpdate
        fields = ["id", "user", "content", "timestamp"]
