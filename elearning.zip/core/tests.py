
from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from .models import Course, Enrollment

User = get_user_model()

class BasicFlowTests(TestCase):
    def setUp(self):
        self.teacher = User.objects.create_user(username="t1", password="pass", role="teacher")
        self.student = User.objects.create_user(username="s1", password="pass", role="student")
    def test_root_redirects_to_login(self):
        resp = self.client.get("/")
        self.assertIn(resp.status_code, (302, 200))
    def test_course_create_and_enroll(self):
        self.client.login(username="t1", password="pass")
        Course.objects.create(name="C1", description="d", teacher=self.teacher)
        self.client.logout()
        self.client.login(username="s1", password="pass")
        course = Course.objects.first()
        self.client.get(reverse("enroll_course", args=[course.id]))
        self.assertTrue(Enrollment.objects.filter(student=self.student, course=course).exists())
    def test_api_users_requires_auth(self):
        resp = self.client.get("/api/users/")
        self.assertEqual(resp.status_code, 403)
        self.client.login(username="t1", password="pass")
        resp = self.client.get("/api/users/")
        self.assertEqual(resp.status_code, 200)
