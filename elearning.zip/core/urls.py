from django.urls import path
from . import views

urlpatterns = [
    path('courses/<int:course_id>/block/<int:student_id>/', views.block_student_view, name='block_student'),
    path('search-users/', views.search_users_view, name='search_users'),
    path('', views.dashboard_view, name='home'),
    path('register/', views.register_view, name='register'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('teacher-dashboard/', views.teacher_dashboard_view, name='teacher_dashboard'),
    path('courses/', views.course_list_view, name='course_list'),
    path('courses/<int:course_id>/enroll/', views.enroll_view, name='enroll_course'),
    path('courses/<int:course_id>/feedback/', views.leave_feedback_view, name='leave_feedback'),
    path('courses/create/', views.create_course_view, name='create_course'),
    path('post-status/', views.post_status_update, name='post_status_update'),
]
