from django.db import models
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseForbidden
from .forms import CustomUserCreationForm, CourseForm, FeedbackForm, StatusUpdateForm
from .models import Course, Enrollment, Feedback, StatusUpdate, User

def register_view(request):
    """Handles user registration with file upload and automatic login."""
    if request.method == "POST":
        form = CustomUserCreationForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect("dashboard")
    else:
        form = CustomUserCreationForm()
    return render(request, "registration/register.html", {"form": form})

@login_required
def dashboard_view(request):
    """Route users to teacher or student dashboards based on role."""
    if getattr(request.user, "role", "student") == "teacher":
        courses = Course.objects.filter(teacher=request.user).order_by("-created_at")
        return render(request, "core/teacher_dashboard.html", {"courses": courses})
    else:
        enrollments = Enrollment.objects.filter(student=request.user).select_related("course")
        status_form = StatusUpdateForm()
        updates = StatusUpdate.objects.select_related("user").order_by("-timestamp")[:20]
        return render(
            request,
            "core/student_dashboard.html",
            {"enrollments": enrollments, "status_form": status_form, "updates": updates},
        )

@login_required
def teacher_dashboard_view(request):
    """Explicit view for tests that look up 'teacher_dashboard'."""
    if getattr(request.user, "role", "student") != "teacher":
        return HttpResponseForbidden("Teachers only")
    courses = Course.objects.filter(teacher=request.user).order_by("-created_at")
    return render(request, "core/teacher_dashboard.html", {"courses": courses})

@login_required
def post_status_update(request):
    """Saves a status update posted by a student."""
    if request.method == "POST":
        form = StatusUpdateForm(request.POST)
        if form.is_valid():
            StatusUpdate.objects.create(user=request.user, **form.cleaned_data)
    return redirect("dashboard")

@login_required
def course_list_view(request):
    """List all courses for students to browse/enroll."""
    courses = Course.objects.order_by("-created_at")
    return render(request, "core/course_list.html", {"courses": courses})

@login_required
def enroll_view(request, course_id):
    """Enroll the current user into a course (students only)."""
    course = get_object_or_404(Course, id=course_id)
    if getattr(request.user, "role", "student") != "student":
        return HttpResponseForbidden("Students only")
    Enrollment.objects.get_or_create(student=request.user, course=course)
    return redirect("course_list")

@login_required
def leave_feedback_view(request, course_id):
    """Allow a student to leave feedback for a course."""
    course = get_object_or_404(Course, id=course_id)
    if getattr(request.user, "role", "student") != "student":
        return HttpResponseForbidden("Students only")
    if request.method == "POST":
        form = FeedbackForm(request.POST)
        if form.is_valid():
            Feedback.objects.create(course=course, student=request.user, **form.cleaned_data)
            return redirect("course_list")
    else:
        form = FeedbackForm()
    return render(request, "core/feedback_form.html", {"form": form, "course": course})

@login_required
def create_course_view(request):
    """Allow a teacher to create a course."""
    if getattr(request.user, "role", "student") != "teacher":
        return HttpResponseForbidden("Teachers only")
    if request.method == "POST":
        form = CourseForm(request.POST, request.FILES)
        if form.is_valid():
            course = form.save(commit=False)
            course.teacher = request.user
            course.save()
            return redirect("teacher_dashboard")
    else:
        form = CourseForm()
    return render(request, "core/create_course.html", {"form": form})


@login_required
def search_users_view(request):
    """Teachers can search for students and teachers by username or real name."""
    if getattr(request.user, "role", "student") != "teacher":
        return HttpResponseForbidden("Teachers only")
    q = request.GET.get("q", "")
    results = []
    if q:
        results = User.objects.filter(models.Q(username__icontains=q) | models.Q(real_name__icontains=q)).order_by("username")[:50]
    return render(request, "core/teacher_dashboard.html", {"courses": Course.objects.filter(teacher=request.user), "q": q, "results": results})


@login_required
def block_student_view(request, course_id, student_id):
    """Teachers can block/unblock a student on their course."""
    if getattr(request.user, "role", "student") != "teacher":
        return HttpResponseForbidden("Teachers only")
    course = get_object_or_404(Course, id=course_id, teacher=request.user)
    enrollment = get_object_or_404(Enrollment, course=course, student_id=student_id)
    enrollment.is_blocked = not enrollment.is_blocked
    enrollment.save()
    return redirect("teacher_dashboard")
