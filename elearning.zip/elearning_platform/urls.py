from rest_framework.routers import DefaultRouter
from django.contrib import admin
from django.urls import path, include

router = DefaultRouter()
from core.api import UserViewSet, CourseViewSet, EnrollmentViewSet, FeedbackViewSet, StatusUpdateViewSet
router.register(r'users', UserViewSet, basename='user')
router.register(r'courses', CourseViewSet, basename='course')
router.register(r'enrollments', EnrollmentViewSet, basename='enrollment')
router.register(r'feedback', FeedbackViewSet, basename='feedback')
router.register(r'status', StatusUpdateViewSet, basename='status')


urlpatterns = [
    path('api/', include(router.urls)),
    path('admin/', admin.site.urls),
    path('accounts/', include('django.contrib.auth.urls')),
    path('chat/', include('chat.urls')),
    path('', include('core.urls')),
]
